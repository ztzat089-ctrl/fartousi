package com.fartousi.os;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    private final int bg = Color.rgb(8, 15, 30);
    private final int panel = Color.rgb(18, 29, 50);
    private final int mint = Color.rgb(103, 232, 193);
    private final int muted = Color.rgb(164, 181, 207);
    private LinearLayout root, body;

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
    private GradientDrawable shape(int color, int radius) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d;
    }
    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setGravity(Gravity.RIGHT); t.setTypeface(Typeface.create("sans-serif", bold ? Typeface.BOLD : Typeface.NORMAL));
        t.setLayoutParams(new LinearLayout.LayoutParams(-1, -2)); return t;
    }
    private LinearLayout column() {
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL);
        l.setLayoutParams(new LinearLayout.LayoutParams(-1, -2)); return l;
    }
    private void pad(View v, int n) { v.setPadding(dp(n), dp(n), dp(n), dp(n)); }
    private void card(String title, String detail, String glyph, Runnable action) {
        LinearLayout c = column(); c.setBackground(shape(panel, 20)); pad(c, 17);
        c.addView(text(glyph + "   " + title, 17, Color.WHITE, true));
        TextView b = text(detail, 13, muted, false); b.setPadding(0, dp(9), 0, 0); c.addView(b);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2); lp.bottomMargin = dp(12); body.addView(c, lp);
        if (action != null) { c.setClickable(true); c.setFocusable(true); c.setOnClickListener(v -> action.run()); }
    }
    private void button(String label, Runnable action) {
        Button b = new Button(this); b.setText(label); b.setTextColor(Color.rgb(5,18,28)); b.setAllCaps(false);
        b.setTextSize(14); b.setBackground(shape(mint, 14));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2); lp.bottomMargin = dp(10); body.addView(b, lp);
        b.setOnClickListener(v -> action.run());
    }
    @Override public void onCreate(Bundle state) {
        super.onCreate(state); getWindow().setStatusBarColor(bg); getWindow().setNavigationBarColor(bg); showHome();
    }
    private void setup(String title) {
        root = column(); root.setBackgroundColor(bg); root.setPadding(dp(18), dp(22), dp(18), dp(12));
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true); body = column(); scroll.addView(body);
        TextView brand = text("FARTOUSI  ◈", 13, mint, true); brand.setGravity(Gravity.CENTER); root.addView(brand);
        TextView heading = text(title, 27, Color.WHITE, true); heading.setPadding(0, dp(18), 0, dp(5)); root.addView(heading);
        root.addView(text("نظامك الخاص • إصدار تجريبي 0.1", 13, muted, false));
        View line = new View(this); line.setBackgroundColor(Color.rgb(40,58,83));
        LinearLayout.LayoutParams linep = new LinearLayout.LayoutParams(-1, dp(1)); linep.topMargin=dp(17); linep.bottomMargin=dp(17); root.addView(line,linep);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        LinearLayout nav = new LinearLayout(this); nav.setGravity(Gravity.CENTER); nav.setOrientation(LinearLayout.HORIZONTAL);
        String[] names = {"الرئيسية", "السحابة", "الجهاز"};
        Runnable[] actions = {this::showHome, this::showCloud, this::showDevice};
        for (int i=0; i<names.length; i++) {
            final int index=i; TextView n=text(names[i],13,mint,true); n.setGravity(Gravity.CENTER); n.setPadding(dp(8),dp(14),dp(8),dp(10));
            n.setOnClickListener(v -> actions[index].run()); nav.addView(n,new LinearLayout.LayoutParams(0,-2,1));
        }
        root.addView(nav); setContentView(root);
    }
    private void showHome() {
        setup("أهلًا بك");
        card("FARTOUSI OS", "واجهة هاتفك الجديدة تبدأ من هنا", "✦", null);
        card("التخزين المحلي", "إدارة ملفات الجهاز عبر تطبيقات Android المعتادة", "▣", this::showDevice);
        card("FARTOUSI Cloud", "واجهة تمهيدية للسحابة والمزامنة", "☁", this::showCloud);
        card("الخصوصية", "هذه النسخة لا تجمع بياناتك ولا تتصل بخادم", "◇", () -> new android.app.AlertDialog.Builder(this).setTitle("الخصوصية").setMessage("لا توجد تحليلات أو إرسال بيانات في هذه النسخة الأولية.").setPositiveButton("حسنًا", null).show());
        TextView foot=text("تم التطوير لمشروع FARTOUSI OS",12,muted,false); foot.setGravity(Gravity.CENTER); foot.setPadding(0,dp(12),0,dp(12)); body.addView(foot);
    }
    private void showCloud() {
        setup("FARTOUSI Cloud");
        card("مساحتك السحابية", "الهدف: 100 GB لكل حساب", "☁", null);
        card("حالة الربط", "غير متصل — لم تتم إضافة عنوان الخادم بعد", "○", null);
        card("مزامنة الملفات", "تُفعّل بعد إعداد API وخادم السحابة", "↻", null);
        card("التشفير", "يلزم ربط خدمة السحابة الفعلية ومفاتيحها", "◇", null);
        button("معلومات الإعداد", () -> new android.app.AlertDialog.Builder(this).setTitle("ربط السحابة").setMessage("هذه شاشة واجهة أولية. يجب نشر خادم FARTOUSI Cloud وضبط عنوان HTTPS قبل تفعيل الحسابات والمزامنة.").setPositiveButton("حسنًا", null).show());
    }
    private void showDevice() {
        setup("الجهاز");
        card("إصدار Android", "Android " + android.os.Build.VERSION.RELEASE, "◉", null);
        card("الشركة المصنّعة", android.os.Build.MANUFACTURER, "▣", null);
        card("طراز الجهاز", android.os.Build.MODEL, "▤", null);
        card("إصدار التطبيق", "FARTOUSI OS 0.1.0", "✦", null);
        button("فتح إعدادات النظام", () -> startActivity(new Intent(android.provider.Settings.ACTION_SETTINGS)));
    }
}
